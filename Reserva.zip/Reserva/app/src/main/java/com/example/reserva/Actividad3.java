package com.example.reserva;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.app.Activity;

public class Actividad3 extends Activity {

    private Button Regresar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad3);
        Regresar = (Button)findViewById(R.id.Regresar);
        Regresar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Volver();
            }
        });
    }

    public void Volver() {
        Intent envia = new Intent(this, MainActivity.class);
        finish();
        startActivity(envia);
    }
}
