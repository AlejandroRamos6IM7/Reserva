package com.example.reserva;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Actividad2 extends Activity {

	String nombre = "",apellido = "", fecha = "", hora = "",texto;
	int personas = 0, dias = 0;
	boolean Comida;
	TextView muestraDatos;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.actividad2);

		muestraDatos = (TextView) findViewById(R.id.muestraDatos);

		Bundle recibe = new Bundle();
		recibe = this.getIntent().getExtras();

		nombre = recibe.getString("nombre");
		apellido = recibe.getString("apellido");
		dias = recibe.getInt("Dias");
		Comida = recibe.getBoolean("Comida");

		personas = recibe.getInt("personas");
		fecha = recibe.getString("fecha");
		hora = recibe.getString("hora");

		if (Comida == false)
			texto = "Sin comida incluida";
		else
			texto = "Con comida incluida";

		muestraDatos.setText("Nombre: " + nombre  + "\n"+ "Apellido: " + apellido
				+ "\n" + dias + " dias" + "\n" + "Comida: " + texto
				+ "\n" + personas
				+ " personas\nFecha: " + fecha + "\nHora: " + hora + "\n");

	}

    public void hacerOtraReserva(View v) {
        Intent envia = new Intent(this, Actividad3.class);
        finish();
        startActivity(envia);
    }

}
